import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {
  BooksScreen,
  ChaptersScreen,
  HomeScreen,
  ReaderScreen,
  StoriesScreen,
  StoryScreen,
} from './src/screens';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Books" component={BooksScreen} options={{ title: 'Livros' }} />
        <Stack.Screen name="Chapters" component={ChaptersScreen} options={{ title: 'Capítulos' }} />
        <Stack.Screen name="Reader" component={ReaderScreen} />
        <Stack.Screen name="Stories" component={StoriesScreen} options={{ title: 'Histórias' }} />
        <Stack.Screen name="Story" component={StoryScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
