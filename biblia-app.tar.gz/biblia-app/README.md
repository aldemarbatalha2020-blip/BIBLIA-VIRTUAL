# Bíblia App (Expo / React Native — Android e iOS)

App para ler a Bíblia e assistir histórias bíblicas em animações simples (ilustrações + narração).

## Princípio de fidelidade ao texto

- O texto bíblico vive em **um único lugar**: `assets/bible/almeida.json`.
- As histórias (`src/stories.ts`) guardam **apenas referências** (livro, capítulo, versículos) e mídia.
  O texto exibido em cada cena é lido da Bíblia instalada, então nunca há texto reescrito ou resumido.
- O app mostra o nome da tradução na tela inicial.

## Como rodar

```bash
npm install
npm run start        # abre o Expo; escaneie o QR code com o app Expo Go
```

## Instalar o texto bíblico (passo obrigatório)

O arquivo `assets/bible/almeida.json` vem vazio de propósito: o texto precisa vir de uma fonte
verificada, não digitado de memória.

1. Escolha uma tradução em **domínio público** (ex.: Almeida Revista e Corrigida de 1898).
   **Confirme a licença da edição específica** antes de publicar — algumas edições modernas
   da Almeida têm direitos autorais (ex.: Almeida Revista e Atualizada, Nova Almeida Atualizada).
2. Baixe o JSON no formato: array com 66 livros em ordem canônica,
   `{ "name": "...", "chapters": [["versículo 1", "versículo 2"], ...] }`.
3. Importe:

```bash
npm run import-bible -- origem.json "Almeida Revista e Corrigida (1898)" "Domínio público" "https://url-da-fonte"
```

4. Confira alguns versículos contra uma edição impressa.

## Adicionar histórias em vídeo

Edite `src/stories.ts`. Cada cena tem:

- `ref`: trecho bíblico (o texto aparece automaticamente)
- `image`: URL ou arquivo da ilustração
- `audio`: narração (opcional). Sem áudio, a cena avança após `durationSec`.

## Próximos passos sugeridos

- Busca por palavra e favoritos/marcadores
- Várias traduções de domínio público e textos originais (hebraico/grego)
- Vídeos hospedados (CDN) e download offline
- Publicação: `eas build` (Expo) para Android/iOS
