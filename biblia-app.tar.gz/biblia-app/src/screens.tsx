import React, { useEffect, useRef, useState } from 'react';
import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Audio } from 'expo-av';
import { bible, getBook, getChapter, getPassage, hasText, refLabel } from './bible';
import { stories } from './stories';

const C = { bg: '#faf7f0', ink: '#2b2118', accent: '#7a4e2d', card: '#ffffff' };

function Empty() {
  return (
    <View style={s.center}>
      <Text style={s.title}>Texto bíblico não instalado</Text>
      <Text style={s.body}>
        Rode "npm run import-bible" com um arquivo de Bíblia de domínio público.
        Veja o README.
      </Text>
    </View>
  );
}

function Button({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable style={s.btn} onPress={onPress}>
      <Text style={s.btnText}>{label}</Text>
    </Pressable>
  );
}

export function HomeScreen({ navigation }: any) {
  return (
    <View style={s.center}>
      <Text style={s.title}>Bíblia</Text>
      <Text style={s.body}>{bible.translation.name}</Text>
      <Button label="Ler a Bíblia" onPress={() => navigation.navigate('Books')} />
      <Button label="Histórias em vídeo" onPress={() => navigation.navigate('Stories')} />
    </View>
  );
}

export function BooksScreen({ navigation }: any) {
  if (!hasText) return <Empty />;
  return (
    <FlatList
      style={s.flex}
      data={bible.books}
      keyExtractor={(b) => b.id}
      renderItem={({ item }) => (
        <Pressable
          style={s.row}
          onPress={() => navigation.navigate('Chapters', { bookId: item.id })}
        >
          <Text style={s.rowText}>{item.name}</Text>
        </Pressable>
      )}
    />
  );
}

export function ChaptersScreen({ route, navigation }: any) {
  const book = getBook(route.params.bookId);
  if (!book) return <Empty />;
  return (
    <FlatList
      style={s.flex}
      numColumns={5}
      data={book.chapters.map((_, i) => i + 1)}
      keyExtractor={(n) => String(n)}
      contentContainerStyle={{ padding: 12 }}
      renderItem={({ item }) => (
        <Pressable
          style={s.chap}
          onPress={() =>
            navigation.navigate('Reader', { bookId: book.id, chapter: item })
          }
        >
          <Text style={s.rowText}>{item}</Text>
        </Pressable>
      )}
    />
  );
}

export function ReaderScreen({ route, navigation }: any) {
  const { bookId, chapter } = route.params;
  const book = getBook(bookId);
  const verses = getChapter(bookId, chapter);
  useEffect(() => {
    navigation.setOptions({ title: `${book?.name ?? ''} ${chapter}` });
  }, [bookId, chapter]);
  const total = book?.chapters.length ?? 0;
  return (
    <ScrollView style={s.flex} contentContainerStyle={{ padding: 16 }}>
      {verses.map((v) => (
        <Text key={v.n} style={s.verse}>
          <Text style={s.num}>{v.n} </Text>
          {v.text}
        </Text>
      ))}
      <View style={s.nav}>
        {chapter > 1 && (
          <Button
            label="‹ Anterior"
            onPress={() => navigation.setParams({ chapter: chapter - 1 })}
          />
        )}
        {chapter < total && (
          <Button
            label="Próximo ›"
            onPress={() => navigation.setParams({ chapter: chapter + 1 })}
          />
        )}
      </View>
    </ScrollView>
  );
}

export function StoriesScreen({ navigation }: any) {
  return (
    <FlatList
      style={s.flex}
      data={stories}
      keyExtractor={(x) => x.id}
      renderItem={({ item }) => (
        <Pressable
          style={s.row}
          onPress={() => navigation.navigate('Story', { storyId: item.id })}
        >
          <Text style={s.rowText}>{item.title}</Text>
        </Pressable>
      )}
    />
  );
}

export function StoryScreen({ route, navigation }: any) {
  const story = stories.find((x) => x.id === route.params.storyId)!;
  const [i, setI] = useState(0);
  const [playing, setPlaying] = useState(false);
  const sound = useRef<Audio.Sound | null>(null);
  const scene = story.scenes[i];
  const verses = getPassage(scene.ref);

  useEffect(() => {
    navigation.setOptions({ title: story.title });
    return () => {
      sound.current?.unloadAsync();
    };
  }, []);

  // Carrega a narração da cena (se houver) e avança sozinho ao terminar.
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    let cancelled = false;
    (async () => {
      await sound.current?.unloadAsync();
      sound.current = null;
      if (!playing) return;
      if (scene.audio) {
        const { sound: snd } = await Audio.Sound.createAsync(
          { uri: scene.audio },
          { shouldPlay: true }
        );
        if (cancelled) return snd.unloadAsync();
        sound.current = snd;
        snd.setOnPlaybackStatusUpdate((st: any) => {
          if (st.didJustFinish) next();
        });
      } else {
        timer = setTimeout(next, (scene.durationSec ?? 10) * 1000);
      }
    })();
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [i, playing]);

  function next() {
    if (i < story.scenes.length - 1) setI(i + 1);
    else setPlaying(false);
  }

  return (
    <View style={s.flex}>
      {scene.image ? (
        <Image source={{ uri: scene.image }} style={s.stage} resizeMode="cover" />
      ) : (
        <View style={[s.stage, s.placeholder]}>
          <Text style={s.body}>Ilustração da cena {i + 1}</Text>
        </View>
      )}
      <ScrollView style={s.flex} contentContainerStyle={{ padding: 16 }}>
        <Text style={s.ref}>{refLabel(scene.ref)}</Text>
        {hasText ? (
          verses.map((v) => (
            <Text key={v.n} style={s.verse}>
              <Text style={s.num}>{v.n} </Text>
              {v.text}
            </Text>
          ))
        ) : (
          <Empty />
        )}
      </ScrollView>
      <View style={s.nav}>
        <Button label="‹" onPress={() => setI(Math.max(0, i - 1))} />
        <Button
          label={playing ? 'Pausar' : 'Reproduzir'}
          onPress={() => setPlaying(!playing)}
        />
        <Button
          label="›"
          onPress={() => setI(Math.min(story.scenes.length - 1, i + 1))}
        />
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  flex: { flex: 1, backgroundColor: C.bg },
  center: { flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  title: { fontSize: 32, fontWeight: '700', color: C.ink },
  body: { fontSize: 16, color: C.ink, textAlign: 'center' },
  btn: { backgroundColor: C.accent, paddingVertical: 12, paddingHorizontal: 22, borderRadius: 10 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  row: { backgroundColor: C.card, padding: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: '#ddd' },
  rowText: { fontSize: 17, color: C.ink },
  chap: { flex: 1, margin: 4, aspectRatio: 1, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center', borderRadius: 8 },
  verse: { fontSize: 19, lineHeight: 30, color: C.ink, marginBottom: 6 },
  num: { fontSize: 12, color: C.accent, fontWeight: '700' },
  nav: { flexDirection: 'row', justifyContent: 'center', gap: 12, padding: 12 },
  stage: { width: '100%', height: 220 },
  placeholder: { backgroundColor: '#e9dfcf', alignItems: 'center', justifyContent: 'center' },
  ref: { fontSize: 14, fontWeight: '700', color: C.accent, marginBottom: 8 },
});
