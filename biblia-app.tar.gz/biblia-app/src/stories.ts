import { Story } from './types';

// Somente referências e mídia. O texto vem da Bíblia instalada.
// Adicione suas ilustrações em "image" e narrações em "audio".
export const stories: Story[] = [
  {
    id: 'davi-golias',
    title: 'Davi e Golias',
    scenes: [
      { ref: { book: '1SA', chapter: 17, from: 4, to: 7 }, durationSec: 12 },
      { ref: { book: '1SA', chapter: 17, from: 32, to: 37 }, durationSec: 15 },
      { ref: { book: '1SA', chapter: 17, from: 48, to: 50 }, durationSec: 12 },
    ],
  },
  {
    id: 'criacao',
    title: 'A Criação',
    scenes: [
      { ref: { book: 'GEN', chapter: 1, from: 1, to: 5 }, durationSec: 14 },
      { ref: { book: 'GEN', chapter: 1, from: 26, to: 28 }, durationSec: 12 },
    ],
  },
  {
    id: 'daniel-leoes',
    title: 'Daniel na cova dos leões',
    scenes: [
      { ref: { book: 'DAN', chapter: 6, from: 16, to: 23 }, durationSec: 18 },
    ],
  },
];
