export type Verse = { n: number; text: string };

export type Book = {
  id: string; // código USFM, ex.: "GEN", "1SA", "JHN"
  name: string;
  chapters: string[][]; // chapters[c][v] = texto do versículo (v+1) do capítulo (c+1)
};

export type Bible = {
  translation: {
    id: string;
    name: string;
    language: string;
    license: string;
    source: string;
  };
  books: Book[];
};

// Referência a um trecho bíblico. O texto NUNCA é copiado para a história:
// ele é sempre lido da Bíblia instalada, garantindo fidelidade ao original.
export type Ref = { book: string; chapter: number; from: number; to: number };

export type Scene = {
  ref: Ref;
  image?: string; // URL ou caminho da ilustração
  audio?: string; // URL ou caminho da narração (opcional)
  durationSec?: number; // tempo da cena se não houver áudio
};

export type Story = {
  id: string;
  title: string;
  scenes: Scene[];
};
