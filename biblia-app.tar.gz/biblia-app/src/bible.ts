import data from '../assets/bible/almeida.json';
import { Bible, Book, Ref, Verse } from './types';

export const bible = data as unknown as Bible;
export const hasText = bible.books.length > 0;

export function getBook(id: string): Book | undefined {
  return bible.books.find((b) => b.id === id);
}

export function getChapter(bookId: string, chapter: number): Verse[] {
  const book = getBook(bookId);
  const verses = book?.chapters[chapter - 1] ?? [];
  return verses.map((text, i) => ({ n: i + 1, text }));
}

export function getPassage(ref: Ref): Verse[] {
  return getChapter(ref.book, ref.chapter).filter(
    (v) => v.n >= ref.from && v.n <= ref.to
  );
}

export function refLabel(ref: Ref): string {
  const name = getBook(ref.book)?.name ?? ref.book;
  const range = ref.from === ref.to ? `${ref.from}` : `${ref.from}-${ref.to}`;
  return `${name} ${ref.chapter}:${range}`;
}
