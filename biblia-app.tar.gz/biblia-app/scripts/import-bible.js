// Uso: npm run import-bible -- <arquivo-origem.json> "<Nome da tradução>" "<Licença>" "<URL da fonte>"
//
// Formato de entrada esperado: array com 66 livros na ordem canônica,
// cada um como { "name": "...", "chapters": [ ["v1", "v2", ...], ... ] }
// (formato usado por vários repositórios abertos de Bíblia em JSON).
//
// O script NÃO altera o texto: apenas copia os versículos e valida a estrutura.

const fs = require('fs');
const path = require('path');

const BOOKS = [
  ['GEN', 'Gênesis'], ['EXO', 'Êxodo'], ['LEV', 'Levítico'], ['NUM', 'Números'],
  ['DEU', 'Deuteronômio'], ['JOS', 'Josué'], ['JDG', 'Juízes'], ['RUT', 'Rute'],
  ['1SA', '1 Samuel'], ['2SA', '2 Samuel'], ['1KI', '1 Reis'], ['2KI', '2 Reis'],
  ['1CH', '1 Crônicas'], ['2CH', '2 Crônicas'], ['EZR', 'Esdras'], ['NEH', 'Neemias'],
  ['EST', 'Ester'], ['JOB', 'Jó'], ['PSA', 'Salmos'], ['PRO', 'Provérbios'],
  ['ECC', 'Eclesiastes'], ['SNG', 'Cantares de Salomão'], ['ISA', 'Isaías'],
  ['JER', 'Jeremias'], ['LAM', 'Lamentações'], ['EZK', 'Ezequiel'], ['DAN', 'Daniel'],
  ['HOS', 'Oseias'], ['JOL', 'Joel'], ['AMO', 'Amós'], ['OBA', 'Obadias'],
  ['JON', 'Jonas'], ['MIC', 'Miqueias'], ['NAM', 'Naum'], ['HAB', 'Habacuque'],
  ['ZEP', 'Sofonias'], ['HAG', 'Ageu'], ['ZEC', 'Zacarias'], ['MAL', 'Malaquias'],
  ['MAT', 'Mateus'], ['MRK', 'Marcos'], ['LUK', 'Lucas'], ['JHN', 'João'],
  ['ACT', 'Atos'], ['ROM', 'Romanos'], ['1CO', '1 Coríntios'], ['2CO', '2 Coríntios'],
  ['GAL', 'Gálatas'], ['EPH', 'Efésios'], ['PHP', 'Filipenses'], ['COL', 'Colossenses'],
  ['1TH', '1 Tessalonicenses'], ['2TH', '2 Tessalonicenses'], ['1TI', '1 Timóteo'],
  ['2TI', '2 Timóteo'], ['TIT', 'Tito'], ['PHM', 'Filemom'], ['HEB', 'Hebreus'],
  ['JAS', 'Tiago'], ['1PE', '1 Pedro'], ['2PE', '2 Pedro'], ['1JN', '1 João'],
  ['2JN', '2 João'], ['3JN', '3 João'], ['JUD', 'Judas'], ['REV', 'Apocalipse'],
];

const [src, name, license, source] = process.argv.slice(2);
if (!src || !name || !license || !source) {
  console.error('Uso: npm run import-bible -- <origem.json> "<Nome>" "<Licença>" "<URL da fonte>"');
  process.exit(1);
}

// Remove BOM, se houver.
const raw = JSON.parse(fs.readFileSync(src, 'utf8').replace(/^﻿/, ''));
if (!Array.isArray(raw) || raw.length !== 66) {
  console.error(`Esperados 66 livros, encontrados ${Array.isArray(raw) ? raw.length : 'formato inválido'}.`);
  process.exit(1);
}

let verseCount = 0;
const books = raw.map((b, i) => {
  if (!Array.isArray(b.chapters) || b.chapters.some((c) => !Array.isArray(c))) {
    console.error(`Livro ${i + 1} (${BOOKS[i][1]}) com estrutura inválida.`);
    process.exit(1);
  }
  b.chapters.forEach((c) => (verseCount += c.length));
  return { id: BOOKS[i][0], name: BOOKS[i][1], chapters: b.chapters };
});

const out = {
  translation: { id: 'almeida', name, language: 'pt', license, source },
  books,
};

const dest = path.join(__dirname, '..', 'assets', 'bible', 'almeida.json');
fs.writeFileSync(dest, JSON.stringify(out));
console.log(`OK: ${books.length} livros, ${verseCount} versículos -> ${dest}`);
console.log('Confira por amostragem alguns versículos contra uma edição impressa antes de publicar.');
